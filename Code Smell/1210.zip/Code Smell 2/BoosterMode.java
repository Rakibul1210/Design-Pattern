public class BoosterMode extends PrintMode{

    private int intensityThreshold;

    @Override
    public void makeConfiguration(){
        boostToMaximumIntesity();
    }
    public void boostToMaximumIntesity() {
        // Uses intensityThreshold 
    }

}
