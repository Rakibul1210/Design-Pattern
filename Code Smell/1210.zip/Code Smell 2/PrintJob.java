import java.util.ArrayList;
import java.util.Queue;

public class PrintJob {


    public void pullJob(PrintRequest request) {
   }


    PrintRequest printRequest = new PrintRequest(new Document(), new TonerSaveMode(), new PageSaveMode(), new BoosterMode());
    ArrayList<PrintRequest> printRequests = new ArrayList<PrintRequest>();


    public void pullJob(){

    }
}
