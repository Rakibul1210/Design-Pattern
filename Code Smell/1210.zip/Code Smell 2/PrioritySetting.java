public class PrioritySetting {
    String priorityLevel;
    public void changePriority(String priorityLevel){
         this.priorityLevel=priorityLevel;
    }
}
