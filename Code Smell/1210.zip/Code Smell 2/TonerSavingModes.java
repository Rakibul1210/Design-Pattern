
class HighTonerSaveMode{

    public int highTonerSaveModeAlgorithm(int colorIntensity){
        return colorIntensity;
    }
}
class MediumTonerSaveMode{
    public int mediumTonerSaveModeAlgorithm(int colorIntensity){
        return colorIntensity;
    }
}
class LowTonerSaveMode{
    public int lowTonerSaveModeAlgorithm(int colorIntensity){
        return colorIntensity;
    }
}